const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
    {
        username: {type: String, required: [true, 'you must provide a username.'], minlength: 4, maxlength: 50, unique: true },
        password: {type: String, required: true},
        email: {type: String, required: true, unique: true},
        isVerified: { type: Boolean, default: true}, // for token verification, default: false once the token routes are set up
        karma: {type: Number, default: 0},
        profilePic: {type: String, default: 'https://90plusworks.github.io/90plusworks/images/user.png'},
        posts: [
            // reference
            {
              type: mongoose.Schema.Types.ObjectId,
              ref: "Post",
            },
          ],
          comments: [
            // reference
            {
              type: mongoose.Schema.Types.ObjectId,
              ref: "Comment",
            },
          ],
    },
    {
        timestamps: true,
        createdAt: "signupAt"
    }
);


const User = mongoose.model('User', userSchema);


module.exports = User;
