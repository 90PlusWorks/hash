module.exports = {
    post: require("./post"),
    auth: require("./auth"),
    user: require("./user"),
    //comment: require("./comments"),
}
