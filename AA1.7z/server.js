/* EXTERNAL MODULES */
const express = require("express");
const path = require("path");
const methodOverride = require("method-override");
const session = require("express-session");
const flash  = require('req-flash');
const MongoStore = require("connect-mongo")(session);

// SECURITY
const rateLimit = require("express-rate-limit");
const helmet = require("helmet");
const mongoSanitize = require('express-mongo-sanitize');
const cors = require("cors");
// logging
const morgan = require("mongoose-morgan");

/* INTERNAL MODULES */
const db = require("./models");
const controllers = require("./controllers");
const {notFound, methodNotAllowed} = require("./middleware/responseHandlers")
const authRequired = require("./middleware/authRequired")

/* INSTANCED MODULES */
const app = express();

/* CONFIGURATION*/

const corsOptions = {
    origin: ["http://localhost:3000"], //set url for live app
    optionsSuccessStatus: 200, //for legacy ports where some legacy browsers will choke on status 204

}
app.use(cors(corsOptions));

// all uses of .env
require("dotenv").config();
const PORT = 3000;//process.env.PORT;

app.set("view engine", "ejs")

//RATE LIMIT SETUP
const LIMIT = rateLimit({
    max: 10000,
    windowMs: 24 * 60 * 60 * 1000, //limited to 10k requests per 1 day in millisecond
    message: "Too many requests",
});

// MIDDLEWARE
app.use(express.static(path.join(__dirname, "public")));
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: false }));
app.use(methodOverride("_method"));
app.use(session({
    resave: false,
    saveUninitialized: false,
    secret: "1234",//process.env.SECRET,
    store: new MongoStore({
        url:  "mongodb+srv://theuns:MmTtGgDdMm1!@cluster0.sjh7lko.mongodb.net/90plusworks-ceco?retryWrites=true&w=majority&appName=Cluster0"
    }),
    cookie: {
        maxAge: 1000 * 60 * 60 * 60 * 24 * 7 * 2
    }
}));
app.use(flash());
app.use(function (req, res, next){
    res.locals.user = req.session.currentUser;
    next();
})
app.use(function(req, res, next){
    res.locals.message = req.flash();
    next();
});
//use rate limiting
app.use(LIMIT);
//HELMET - reset headers in response for security
//app.use(helmet());
// SANITIZE DATA coming in from req.body
app.use(mongoSanitize());
// logging
const morganOptions = {
    connectionString:  "mongodb+srv://theuns:MmTtGgDdMm1!@cluster0.sjh7lko.mongodb.net/90plusworks-ceco?retryWrites=true&w=majority&appName=Cluster0",//process.env.MONGODB_URI,
}
app.use(morgan(morganOptions, {
    skip: function(req, res){ //adding this for tracking error only
        return res.statusCode < 400;
    }
}, "dev"));
// moment - formatting time
app.locals.moment = require('moment');


/* ROUTES */

// VIEW ROUTES
app.get("/", async (req, res) => {
    try {
        const currentevent = req
        const foundPosts = await db.Post.find({});
        const allEvent_Names = await db.Post.distinct("cecoevent");
        const context = {
            posts: foundPosts,
            user: req.session.currentUser,
            cecoevents: allEvent_Names,
            currentevent: req.session.currentUser.currentevent,
        };
        res.render("posts/index.ejs", context);
    } catch (error) {
        res.send({ message: "Internal server error" });
    }
});
app.get("/:id/edit", async (req, res) => {
    try {
      const foundPost = await db.Post.findById(req.params.id);
      const context = {
        post: foundPost,
        user: req.session.currentUser,
      };
      console.log(foundPost)
      res.render("posts/edit.ejs", context);
    } catch (error) {
      req.flash('error', error);
      return res.redirect("404");                                                          // redirect to 404 Page if there is an error
    }
  });
 

app.get("/x", async (req, res) => {
    try {
        const foundPosts = await db.Post.find({});
        const allEvent_Names = await db.Post.distinct("cecoevent");
        const context = {
            posts: foundPosts,
            user: req.session.currentUser,
            cecoevents: allEvent_Names,
        };
        res.render("posts/indexNew.ejs", context);
    } catch (error) {
        res.send({ message: "Internal server error" });
    }
});
app.get("/z", async (req, res) => {
    try {
        const foundPosts = await db.Post.find({});
        const allEvent_Names = await db.Post.distinct("cecoevent");
        const context = {
            posts: foundPosts,
            user: req.session.currentUser,
            cecoevents: allEvent_Names,
        };
        res.render("posts/indexCat.ejs", context);
    } catch (error) {
        res.send({ message: "Internal server error" });
    }
});
app.get("/y", async (req, res) => {
    try {
        const foundPosts = await db.Post.find({});
        const allEvent_Names = await db.Post.distinct("cecoevent");
        const context = {
            posts: foundPosts,
            user: req.session.currentUser,
            cecoevents: allEvent_Names,
        };
        res.render("posts/indexItem.ejs", context);
    } catch (error) {
        res.send({ message: "Internal server error" });
    }
});

// AUTH ROUTES
app.use("/", controllers.auth);

// USER ROUTES
app.use("/users", authRequired, controllers.user);

// POSTS ROUTES
app.use("/posts", authRequired, controllers.post);

// RESPONSE MIDDLEWARE
app.get("/*", notFound);
app.use(methodNotAllowed);
app.use(function (err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};
  
    // render the error page
    console.error(err);
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });


// SERVER LISTENER
app.listen(process.env.PORT || 3000, function () {
    console.log(`server up and running on PORT ${PORT}`)
})


