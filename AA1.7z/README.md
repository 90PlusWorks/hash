<h1 align="center">
  <a href="https://listevents.herokuapp.com/">
    listEvents
  </a>
</h1>
<p align="center">
<p align="center"><a href="https://listevents.herokuapp.com/">Link to List Events</a></p>
<p align="center">Username: demouser | Password: Demo2020
</p>

<p align="center">
    <p>Event Costing</p>
    <p> </p>
    <a href="https://listevents.herokuapp.com/">Link to listEvents</a>
</p>

## Wireframes

</p>

## User Stories



</br> Color Used: </br>
Navbar - ![#e3f2fd](https://via.placeholder.com/15/e3f2fd/000000?text=+) `#e3f2fd` Navbar Font - ![#307DF6](https://via.placeholder.com/15/307DF6/000000?text=+) `#307DF6` Body Font - ![#007CFF](https://via.placeholder.com/15/007CFF/000000?text=+) `#007CFF`  Sub-body Font- ![#989898](https://via.placeholder.com/15/989898/000000?text=+) `#989898`

</p>

## ERD
### Version 1


### Version 0


## MVP
A costing board that allows registered users to browse and create costs for events.
Registered users are:
1. authorized to create Events / Costs on threads 

## Milestones
- Working Server with Routes
- Models with Schema setup
- CRUD functionality
- Acceptance System
- User Authentication
- Views Styling

## Stretch Goals
- 
- mobile friendly


## Technologies Used
- MongoDB
- Mongoose
- JavaScript
- HTML&CSS
- BootStrap
- jQuery
- moment.js
- sweet alert
- express session
- bcrypt
- req-flash
- Express Rate Limit
- helmet.js
- express-mongo-sanitize
- CORS (cross origin resource sharing)
- mongoose-morgan


## Version 0.1

